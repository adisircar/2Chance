import { useQuery } from "@tanstack/react-query";
import { HousingCard } from "@/components/HousingCard";
import type { Housing } from "@shared/schema";

export default function Housing() {
  const { data: housing, isLoading } = useQuery<Housing[]>({
    queryKey: ["/api/housing"],
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-gray-200 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Available Housing</h1>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {housing?.map((h) => (
          <HousingCard key={h.id} housing={h} />
        ))}
      </div>
    </div>
  );
}
