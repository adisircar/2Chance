import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const news = [
  {
    id: 1,
    title: "Local Job Fair Next Week",
    date: "2024-03-15",
    description: "Major employers in the area will be conducting on-site interviews.",
    image: "https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a"
  },
  {
    id: 2,
    title: "Housing Assistance Program Launches",
    date: "2024-03-10",
    description: "New program offers rental assistance to recently released individuals.",
    image: "https://images.unsplash.com/photo-1504805572947-34fad45aed93"
  }
];

export default function News() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">News & Events</h1>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {news.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <img src={item.image} alt={item.title} className="h-48 w-full object-cover" />
            <CardHeader>
              <CardTitle>{item.title}</CardTitle>
              <p className="text-sm text-gray-500">{item.date}</p>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
