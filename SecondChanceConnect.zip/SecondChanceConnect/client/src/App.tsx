import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { Navbar } from "@/components/Navbar";
import { ChatWidget } from "@/components/ChatWidget";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Jobs from "@/pages/Jobs";
import Housing from "@/pages/Housing";
import Community from "@/pages/Community";
import News from "@/pages/News";
import Mentorship from "@/pages/Mentorship";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/jobs" component={Jobs} />
      <Route path="/housing" component={Housing} />
      <Route path="/community" component={Community} />
      <Route path="/news" component={News} />
      <Route path="/mentorship" component={Mentorship} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main>
          <Router />
        </main>
        <ChatWidget />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}