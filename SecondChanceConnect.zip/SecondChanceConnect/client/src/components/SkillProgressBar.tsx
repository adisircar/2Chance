import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star } from "lucide-react";

const skills = [
  {
    name: "Job Readiness",
    progress: 65,
    level: "Intermediate",
    description: "Resume writing, interview skills, and workplace etiquette",
  },
  {
    name: "Financial Literacy",
    progress: 40,
    level: "Beginner",
    description: "Budgeting, saving, and understanding credit",
  },
  {
    name: "Digital Skills",
    progress: 30,
    level: "Beginner",
    description: "Computer basics, internet usage, and online safety",
  },
  {
    name: "Life Skills",
    progress: 50,
    level: "Intermediate",
    description: "Time management, communication, and problem-solving",
  },
];

export function SkillProgressBar() {
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Your Skills Progress
          </CardTitle>
          <div className="flex items-center gap-2">
            <Star className="h-4 w-4 text-yellow-500" />
            <span className="text-sm font-medium">Total XP: 2,450</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="space-y-2"
            >
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">{skill.name}</h3>
                  <p className="text-sm text-gray-500">{skill.description}</p>
                </div>
                <Badge variant={skill.progress >= 50 ? "success" : "secondary"}>
                  {skill.level}
                </Badge>
              </div>
              <div className="relative">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 0.5 }}
                >
                  <Progress value={skill.progress} className="h-2" />
                </motion.div>
                <span className="absolute right-0 top-0 -mt-1 text-sm font-medium">
                  {skill.progress}%
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 p-4 bg-blue-50 rounded-lg"
        >
          <h4 className="font-semibold mb-2">Keep Going!</h4>
          <p className="text-sm text-gray-600">
            Complete more lessons and activities to level up your skills. Your next milestone: Achieving Intermediate level in Digital Skills.
          </p>
        </motion.div>
      </CardContent>
    </Card>
  );
}
