import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Job } from "@shared/schema";

export function JobCard({ job }: { job: Job }) {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <img src={job.image} alt={job.company} className="h-48 w-full object-cover rounded-md" />
        <CardTitle className="mt-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-xl font-bold">{job.title}</h3>
              <p className="text-sm text-gray-500">{job.company}</p>
            </div>
            {job.felon_friendly && (
              <Badge variant="secondary">Second Chance Employer</Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <div className="flex-1">
          <p className="text-sm text-gray-600 mb-2">{job.location}</p>
          <p className="text-sm text-gray-600 mb-4">{job.salary}</p>
          <p className="text-sm">{job.description}</p>
        </div>
        <Button className="w-full mt-4">Apply Now</Button>
      </CardContent>
    </Card>
  );
}
