import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Resource } from "@shared/schema";

export function ResourceCard({ resource }: { resource: Resource }) {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle>
          <div>
            <h3 className="text-xl font-bold">{resource.title}</h3>
            <p className="text-sm text-blue-600">{resource.category}</p>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <div className="flex-1">
          <p className="text-sm mb-4">{resource.description}</p>
          {resource.contact && (
            <p className="text-sm text-gray-600 mb-2">Contact: {resource.contact}</p>
          )}
        </div>
        {resource.website && (
          <Button className="w-full mt-4" variant="outline" asChild>
            <a href={resource.website} target="_blank" rel="noopener noreferrer">
              Visit Website
            </a>
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
