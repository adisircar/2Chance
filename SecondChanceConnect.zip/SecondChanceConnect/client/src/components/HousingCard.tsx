import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Housing } from "@shared/schema";

export function HousingCard({ housing }: { housing: Housing }) {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <img src={housing.image} alt={housing.title} className="h-48 w-full object-cover rounded-md" />
        <CardTitle className="mt-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-xl font-bold">{housing.title}</h3>
              <p className="text-sm text-gray-500">{housing.location}</p>
            </div>
            {housing.felon_friendly && (
              <Badge variant="secondary">Second Chance Housing</Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <div className="flex-1">
          <p className="text-sm text-gray-600 mb-2">${housing.price}/month</p>
          <p className="text-sm">{housing.description}</p>
        </div>
        <Button className="w-full mt-4">Learn More</Button>
      </CardContent>
    </Card>
  );
}
