import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest } from "@/lib/queryClient";
import type { MentorPreferences, Mentor } from "@shared/schema";
import { insertMentorPreferencesSchema } from "@shared/schema";
import { z } from "zod";

const preferenceSchema = insertMentorPreferencesSchema.extend({
  interests: z.array(z.string()),
  preferredMentorType: z.array(z.string()),
  goals: z.array(z.string()),
});

type FormData = z.infer<typeof preferenceSchema>;

const interests = [
  { id: "job_readiness", label: "Job Readiness" },
  { id: "entrepreneurship", label: "Entrepreneurship" },
  { id: "spiritual_guidance", label: "Spiritual Guidance" },
  { id: "life_skills", label: "Life Skills" },
  { id: "counseling", label: "Counseling" },
  { id: "education", label: "Education" },
];

const mentorTypes = [
  { id: "business_leader", label: "Business Leader" },
  { id: "community_leader", label: "Community Leader" },
  { id: "spiritual_leader", label: "Spiritual Leader" },
  { id: "career_coach", label: "Career Coach" },
];

const commitmentLevels = [
  { value: "weekly", label: "Weekly Meetings" },
  { value: "biweekly", label: "Bi-weekly Meetings" },
  { value: "monthly", label: "Monthly Meetings" },
];

export function MentorMatchingForm() {
  const [step, setStep] = useState(1);
  const form = useForm<FormData>({
    resolver: zodResolver(preferenceSchema),
    defaultValues: {
      interests: [],
      preferredMentorType: [],
      goals: [],
      commitmentLevel: "biweekly",
      userId: 1, // For testing, in production this would come from auth context
    },
  });

  const { mutate: submitPreferences, isPending } = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/mentor-preferences", data);
      return res.json();
    },
    onSuccess: () => {
      setStep(2);
    },
  });

  const { data: matches } = useQuery<Array<{ mentor: Mentor; score: number }>>({
    queryKey: ["/api/mentor-matches"],
    enabled: step === 2,
  });

  const onSubmit = (data: FormData) => {
    submitPreferences(data);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Find Your Mentor Match</CardTitle>
      </CardHeader>
      <CardContent>
        {step === 1 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="interests"
                  render={() => (
                    <FormItem>
                      <FormLabel>What areas are you interested in?</FormLabel>
                      <div className="grid grid-cols-2 gap-4">
                        {interests.map((interest) => (
                          <FormField
                            key={interest.id}
                            control={form.control}
                            name="interests"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(interest.id)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, interest.id])
                                        : field.onChange(
                                            field.value?.filter((value) => value !== interest.id)
                                          );
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  {interest.label}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="preferredMentorType"
                  render={() => (
                    <FormItem>
                      <FormLabel>What type of mentor are you looking for?</FormLabel>
                      <div className="grid grid-cols-2 gap-4">
                        {mentorTypes.map((type) => (
                          <FormField
                            key={type.id}
                            control={form.control}
                            name="preferredMentorType"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(type.id)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, type.id])
                                        : field.onChange(
                                            field.value?.filter((value) => value !== type.id)
                                          );
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  {type.label}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="commitmentLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferred meeting frequency</FormLabel>
                      <FormControl>
                        <select
                          {...field}
                          className="w-full p-2 border rounded-md"
                        >
                          {commitmentLevels.map((level) => (
                            <option key={level.value} value={level.value}>
                              {level.label}
                            </option>
                          ))}
                        </select>
                      </FormControl>
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={isPending}>
                  {isPending ? "Finding matches..." : "Find My Mentor Match"}
                </Button>
              </form>
            </Form>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <h3 className="text-lg font-medium">Your Mentor Matches</h3>
            <div className="space-y-4">
              {matches?.map(({ mentor, score }) => (
                <Card key={mentor.id} className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{mentor.bio.split('.')[0]}</h4>
                      <p className="text-sm text-gray-600">{mentor.expertise.join(', ')}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-medium">
                        {Math.round((score / 100) * 100)}% Match
                      </span>
                    </div>
                  </div>
                  <Button className="w-full mt-4">Connect</Button>
                </Card>
              ))}
            </div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}