import { motion } from "framer-motion";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Circle } from "lucide-react";
import { CelebrationPopup } from "./CelebrationPopup";

const milestones = [
  { id: 1, title: "Profile Setup", completed: true },
  { id: 2, title: "Housing Search", completed: false },
  { id: 3, title: "Job Applications", completed: false },
  { id: 4, title: "Community Connection", completed: false },
];

export function DashboardTracker() {
  const [showCelebration, setShowCelebration] = useState(false);
  const [currentMilestone, setCurrentMilestone] = useState({
    title: "",
    message: "",
  });

  const completedCount = milestones.filter(m => m.completed).length;
  const progress = (completedCount / milestones.length) * 100;

  const handleMilestoneClick = (milestone: typeof milestones[0]) => {
    if (!milestone.completed) {
      setCurrentMilestone({
        title: "Milestone Completed! 🎉",
        message: `Congratulations on completing ${milestone.title}! Keep up the great work on your journey.`,
      });
      setShowCelebration(true);
      // In a real app, this would update the milestone status in the backend
    }
  };

  return (
    <>
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              Your Journey
            </motion.div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative mb-8">
            <motion.div
              className="w-full h-2 bg-blue-100 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                className="h-full bg-blue-600 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.8, delay: 0.3 }}
              />
            </motion.div>
          </div>

          <div className="space-y-4">
            {milestones.map((milestone, index) => (
              <motion.div
                key={milestone.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-3 cursor-pointer"
                onClick={() => handleMilestoneClick(milestone)}
              >
                {milestone.completed ? (
                  <CheckCircle2 className="text-blue-600 h-5 w-5 fill-current" />
                ) : (
                  <Circle className="text-gray-400 h-5 w-5" />
                )}
                <span className="flex-1">{milestone.title}</span>
                {milestone.completed ? (
                  <Badge variant="success">Completed</Badge>
                ) : (
                  <Badge variant="secondary">In Progress</Badge>
                )}
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-6 p-4 bg-blue-50 rounded-lg"
          >
            <h4 className="font-semibold mb-2">Next Steps</h4>
            <p className="text-sm text-gray-600">
              Focus on finding suitable housing options. Browse our housing listings and reach out to
              second-chance friendly properties.
            </p>
          </motion.div>
        </CardContent>
      </Card>

      <CelebrationPopup
        isVisible={showCelebration}
        onClose={() => setShowCelebration(false)}
        milestone={currentMilestone}
      />
    </>
  );
}