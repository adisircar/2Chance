import { jobs, housing, resources, users } from "@shared/schema";
import type { User, Job, Housing, Resource, InsertUser, InsertJob, InsertHousing, InsertResource } from "@shared/schema";
import type { Mentor, InsertMentor, MentorPreferences, InsertMentorPreferences, MentorMatch, InsertMentorMatch } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getJobs(): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;

  getHousing(): Promise<Housing[]>;
  getHousingById(id: number): Promise<Housing | undefined>;
  createHousing(housing: InsertHousing): Promise<Housing>;

  getResources(): Promise<Resource[]>;
  getResource(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;

  // Mentor-related methods
  getMentor(id: number): Promise<Mentor | undefined>;
  createMentor(mentor: InsertMentor): Promise<Mentor>;
  updateMentorStatus(id: number, isActive: boolean): Promise<void>;
  getAllMentors(): Promise<Mentor[]>;

  getMentorPreferences(userId: number): Promise<MentorPreferences | undefined>;
  createMentorPreferences(preferences: InsertMentorPreferences): Promise<MentorPreferences>;

  findMatchingMentors(userId: number): Promise<Array<{ mentor: Mentor; score: number }>>;
  createMentorMatch(match: InsertMentorMatch): Promise<MentorMatch>;
  getMentorMatches(userId: number): Promise<MentorMatch[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private mentors: Map<number, Mentor>;
  private mentorPreferences: Map<number, MentorPreferences>;
  private mentorMatches: Map<number, MentorMatch>;
  private jobs: Map<number, Job>;
  private housing: Map<number, Housing>;
  private resources: Map<number, Resource>;
  private currentId: { [key: string]: number };

  constructor() {
    this.users = new Map();
    this.mentors = new Map();
    this.mentorPreferences = new Map();
    this.mentorMatches = new Map();
    this.jobs = new Map();
    this.housing = new Map();
    this.resources = new Map();
    this.currentId = {
      users: 1, jobs: 1, housing: 1, resources: 1,
      mentors: 1, mentorPreferences: 1, mentorMatches: 1
    };
    this.seedData();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const newUser: User = {
      id,
      ...user,
      releaseDate: user.releaseDate || null
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values());
  }

  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(job: InsertJob): Promise<Job> {
    const id = this.currentId.jobs++;
    const newJob: Job = {
      id,
      ...job,
      salary: job.salary || null,
      felon_friendly: job.felon_friendly ?? true
    };
    this.jobs.set(id, newJob);
    return newJob;
  }

  async getHousingById(id: number): Promise<Housing | undefined> {
    return this.housing.get(id);
  }

  async getHousing(): Promise<Housing[]> {
    return Array.from(this.housing.values());
  }

  async createHousing(housing: InsertHousing): Promise<Housing> {
    const id = this.currentId.housing++;
    const newHousing: Housing = {
      id,
      ...housing,
      felon_friendly: housing.felon_friendly ?? true
    };
    this.housing.set(id, newHousing);
    return newHousing;
  }

  async getResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }

  async getResource(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.currentId.resources++;
    const newResource: Resource = {
      id,
      ...resource,
      contact: resource.contact || null,
      website: resource.website || null
    };
    this.resources.set(id, newResource);
    return newResource;
  }

  // Mentor-related methods
  async getMentor(id: number): Promise<Mentor | undefined> {
    return this.mentors.get(id);
  }

  async getAllMentors(): Promise<Mentor[]> {
    return Array.from(this.mentors.values());
  }

  async createMentor(mentorData: InsertMentor): Promise<Mentor> {
    const id = this.currentId.mentors++;
    const mentor: Mentor = {
      id,
      ...mentorData,
      userId: mentorData.userId || null,
      isActive: mentorData.isActive ?? true
    };
    this.mentors.set(id, mentor);
    return mentor;
  }

  async updateMentorStatus(id: number, isActive: boolean): Promise<void> {
    const mentor = await this.getMentor(id);
    if (mentor) {
      mentor.isActive = isActive;
      this.mentors.set(id, mentor);
    }
  }

  async getMentorPreferences(userId: number): Promise<MentorPreferences | undefined> {
    return Array.from(this.mentorPreferences.values()).find(
      (pref) => pref.userId === userId
    );
  }

  async createMentorPreferences(preferences: InsertMentorPreferences): Promise<MentorPreferences> {
    const id = this.currentId.mentorPreferences++;
    const newPreferences: MentorPreferences = {
      id,
      ...preferences,
      userId: preferences.userId || null
    };
    this.mentorPreferences.set(id, newPreferences);
    return newPreferences;
  }

  async findMatchingMentors(userId: number): Promise<Array<{ mentor: Mentor; score: number }>> {
    const userPreferences = await this.getMentorPreferences(userId);
    if (!userPreferences) {
      return [];
    }

    const matches = Array.from(this.mentors.values())
      .filter(mentor => mentor.isActive)
      .map(mentor => {
        let score = 0;

        const expertiseMatch = mentor.expertise.filter(exp => 
          userPreferences.interests.includes(exp)).length;
        score += expertiseMatch * 10;

        const availabilityScore = mentor.availability.days.length * 5;
        score += availabilityScore;

        return { mentor, score };
      })
      .filter(({ score }) => score > 20)
      .sort((a, b) => b.score - a.score);

    return matches.slice(0, 5);
  }

  async createMentorMatch(match: InsertMentorMatch): Promise<MentorMatch> {
    const id = this.currentId.mentorMatches++;
    const newMatch: MentorMatch = {
      id,
      ...match,
      mentorId: match.mentorId || null,
      menteeId: match.menteeId || null,
      createdAt: match.createdAt || new Date()
    };
    this.mentorMatches.set(id, newMatch);
    return newMatch;
  }

  async getMentorMatches(userId: number): Promise<MentorMatch[]> {
    return Array.from(this.mentorMatches.values()).filter(
      match => match.menteeId === userId || match.mentorId === userId
    );
  }

  private seedData() {
    const sampleJobs: InsertJob[] = [
      {
        title: "Warehouse Associate",
        company: "LogiCorp",
        location: "Phoenix, AZ",
        description: "Entry level position with training provided. No experience required.",
        salary: "$16-18/hr",
        image: "https://images.unsplash.com/photo-1484981138541-3d074aa97716",
        felon_friendly: true
      },
      {
        title: "Kitchen Staff",
        company: "Fresh Start Dining",
        location: "Portland, OR",
        description: "Join our kitchen team. Full training provided. Flexible schedules.",
        salary: "$15-17/hr",
        image: "https://images.unsplash.com/photo-1425421669292-0c3da3b8f529",
        felon_friendly: true
      }
    ];

    const sampleHousing: InsertHousing[] = [
      {
        title: "Supportive Housing Complex",
        location: "Seattle, WA",
        description: "Affordable housing with on-site support services",
        price: 800,
        image: "https://images.unsplash.com/photo-1521903683084-0d0dbeaed969",
        felon_friendly: true
      },
      {
        title: "Fresh Start Apartments",
        location: "Denver, CO",
        description: "Second chance leasing available. No credit check required.",
        price: 950,
        image: "https://images.unsplash.com/photo-1516156008625-3a9d6067fab5",
        felon_friendly: true
      }
    ];

    const sampleResources: InsertResource[] = [
      {
        title: "Employment Workshop",
        description: "Free weekly workshop on resume writing and interview skills",
        category: "Employment",
        contact: "workshops@reentry.org",
        website: "https://workshops.reentry.org"
      },
      {
        title: "Legal Aid Clinic",
        description: "Free legal consultation for record expungement",
        category: "Legal",
        contact: "legal@reentry.org",
        website: "https://legal.reentry.org"
      }
    ];

    const sampleMentors: InsertMentor[] = [
      {
        userId: 1,
        bio: "Business owner with 15 years experience in construction. Passionate about giving second chances.",
        expertise: ["construction", "entrepreneurship", "job_readiness"],
        availability: {
          days: ["Monday", "Wednesday"],
          timeSlots: ["morning", "evening"]
        },
        isActive: true
      },
      {
        userId: 2,
        bio: "Community leader and pastor. Here to provide spiritual and emotional support.",
        expertise: ["spiritual_guidance", "counseling", "life_skills"],
        availability: {
          days: ["Tuesday", "Thursday", "Sunday"],
          timeSlots: ["afternoon", "evening"]
        },
        isActive: true
      }
    ];

    sampleJobs.forEach(job => this.createJob(job));
    sampleHousing.forEach(h => this.createHousing(h));
    sampleResources.forEach(r => this.createResource(r));
    sampleMentors.forEach(mentor => this.createMentor(mentor));
  }
}

export const storage = new MemStorage();