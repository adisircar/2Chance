import type { Express } from "express";
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertUserSchema, insertJobSchema, insertHousingSchema, insertResourceSchema, insertMentorSchema, insertMentorPreferencesSchema, insertMentorMatchSchema } from "@shared/schema";

interface ChatMessage {
  type: 'message' | 'status';
  sender: string;
  content: string;
  timestamp: string;
}

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const activeMentors = new Map<string, WebSocket>();
  const userChats = new Map<string, WebSocket>();

  wss.on('connection', (ws) => {
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString()) as ChatMessage;

        // Broadcast to appropriate recipients
        if (message.type === 'message') {
          if (message.sender.startsWith('mentor_')) {
            const userId = message.sender.replace('mentor_', '');
            const userWs = userChats.get(userId);
            if (userWs?.readyState === WebSocket.OPEN) {
              userWs.send(JSON.stringify(message));
            }
          } else {
            // Find available mentor and send message
            for (const [, mentorWs] of activeMentors) {
              if (mentorWs.readyState === WebSocket.OPEN) {
                mentorWs.send(JSON.stringify(message));
                break;
              }
            }
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      // Cleanup connections
      for (const [id, socket] of activeMentors) {
        if (socket === ws) {
          activeMentors.delete(id);
        }
      }
      for (const [id, socket] of userChats) {
        if (socket === ws) {
          userChats.delete(id);
        }
      }
    });
  });

  // Users
  app.post("/api/users", async (req, res) => {
    const parsed = insertUserSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid user data" });
    }
    const user = await storage.createUser(parsed.data);
    res.json(user);
  });

  // Jobs
  app.get("/api/jobs", async (_req, res) => {
    const jobs = await storage.getJobs();
    res.json(jobs);
  });

  app.get("/api/jobs/:id", async (req, res) => {
    const job = await storage.getJob(parseInt(req.params.id));
    if (!job) return res.status(404).json({ error: "Job not found" });
    res.json(job);
  });

  // Housing
  app.get("/api/housing", async (_req, res) => {
    const housing = await storage.getHousing();
    res.json(housing);
  });

  app.get("/api/housing/:id", async (req, res) => {
    const housing = await storage.getHousingById(parseInt(req.params.id));
    if (!housing) return res.status(404).json({ error: "Housing not found" });
    res.json(housing);
  });

  // Resources
  app.get("/api/resources", async (_req, res) => {
    const resources = await storage.getResources();
    res.json(resources);
  });

  app.get("/api/resources/:id", async (req, res) => {
    const resource = await storage.getResource(parseInt(req.params.id));
    if (!resource) return res.status(404).json({ error: "Resource not found" });
    res.json(resource);
  });

  // Mentor routes
  app.get("/api/mentors", async (_req, res) => {
    const mentors = await storage.getAllMentors();
    res.json(mentors.filter(mentor => mentor.isActive));
  });

  app.post("/api/mentors", async (req, res) => {
    const parsed = insertMentorSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid mentor data" });
    }
    const mentor = await storage.createMentor(parsed.data);
    res.json(mentor);
  });

  app.post("/api/mentor-preferences", async (req, res) => {
    const parsed = insertMentorPreferencesSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid preferences data" });
    }
    const preferences = await storage.createMentorPreferences(parsed.data);
    res.json(preferences);
  });

  app.get("/api/mentor-matches/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    const matches = await storage.findMatchingMentors(userId);
    res.json(matches);
  });

  app.post("/api/mentor-matches", async (req, res) => {
    const parsed = insertMentorMatchSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid match data" });
    }
    const match = await storage.createMentorMatch(parsed.data);
    res.json(match);
  });

  return httpServer;
}