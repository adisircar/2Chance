import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  releaseDate: timestamp("release_date"),
});

export const mentors = pgTable("mentors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  bio: text("bio").notNull(),
  expertise: json("expertise").notNull().$type<string[]>(),
  availability: json("availability").notNull().$type<{
    days: string[];
    timeSlots: string[];
  }>(),
  isActive: boolean("is_active").default(true),
});

export const mentorPreferences = pgTable("mentor_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  interests: json("interests").notNull().$type<string[]>(),
  preferredMentorType: json("preferred_mentor_type").notNull().$type<string[]>(),
  goals: json("goals").notNull().$type<string[]>(),
  commitmentLevel: text("commitment_level").notNull(),
});

export const mentorMatches = pgTable("mentor_matches", {
  id: serial("id").primaryKey(),
  mentorId: integer("mentor_id").references(() => mentors.id),
  menteeId: integer("mentee_id").references(() => users.id),
  status: text("status").notNull(), // pending, active, completed
  matchScore: integer("match_score").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  salary: text("salary"),
  image: text("image").notNull(),
  felon_friendly: boolean("felon_friendly").default(true),
});

export const housing = pgTable("housing", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  image: text("image").notNull(),
  felon_friendly: boolean("felon_friendly").default(true),
});

export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  contact: text("contact"),
  website: text("website"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  releaseDate: true,
});

export const insertJobSchema = createInsertSchema(jobs);
export const insertHousingSchema = createInsertSchema(housing);
export const insertResourceSchema = createInsertSchema(resources);
export const insertMentorSchema = createInsertSchema(mentors).omit({ id: true });
export const insertMentorPreferencesSchema = createInsertSchema(mentorPreferences).omit({ id: true });
export const insertMentorMatchSchema = createInsertSchema(mentorMatches).omit({ id: true });

export type User = typeof users.$inferSelect;
export type Job = typeof jobs.$inferSelect;
export type Housing = typeof housing.$inferSelect;
export type Resource = typeof resources.$inferSelect;
export type Mentor = typeof mentors.$inferSelect;
export type MentorPreferences = typeof mentorPreferences.$inferSelect;
export type MentorMatch = typeof mentorMatches.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type InsertHousing = z.infer<typeof insertHousingSchema>;
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type InsertMentor = z.infer<typeof insertMentorSchema>;
export type InsertMentorPreferences = z.infer<typeof insertMentorPreferencesSchema>;
export type InsertMentorMatch = z.infer<typeof insertMentorMatchSchema>;